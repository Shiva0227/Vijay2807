package com.cg.bank.exception;

public class CustomerException extends Exception{

	

	public CustomerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
