package com.cg.bank.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface CustomerService {
	public String createAccount(Customer c,Account a) throws ClassNotFoundException, SQLException;
	public double showBalance(String accountNo) throws ClassNotFoundException, SQLException;
	public double deposit(double amount,String accountNo) throws ClassNotFoundException, SQLException;
	public double withdraw(double amount,String accounNo) throws ClassNotFoundException, SQLException;
	public boolean fundTransfer(double amount,String accountNo1,String accountNo2) throws ClassNotFoundException, SQLException;
	public List<Account> printTransaction(String accountno) throws SQLException, ClassNotFoundException;
	public boolean validateCustomerName(String name);
	public boolean validateCustomerNo(String mobileNo);
	

}
