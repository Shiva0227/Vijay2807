package com.cg.bank.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class Util {
	
    	public static Connection connection() throws SQLException, ClassNotFoundException
    	{
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
    		return con;
    	}
}
